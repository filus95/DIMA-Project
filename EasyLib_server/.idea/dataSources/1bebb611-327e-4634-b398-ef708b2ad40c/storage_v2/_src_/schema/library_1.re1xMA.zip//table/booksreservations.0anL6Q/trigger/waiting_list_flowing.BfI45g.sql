create trigger waiting_list_flowing
  after DELETE
  on booksreservations
  for each row
  begin
    
    declare cond integer;
    declare user_id integer;
    declare reservation_date DATETIME;
    declare start_res_date DATE;
    declare end_res_date DATE;
    declare quantity integer;

    set cond = (select waiting_position from library_1.waitinglist where waitinglist.book_identifier =
                                                          OLD.book_identifier and waiting_position = 1);
    
    if cond > 0 then 
      
      set user_id = (select user_id from waitinglist where waitinglist.book_identifier =
                                                           OLD.book_identifier and waiting_position = 1);
      set reservation_date = (select waitinglist.reservation_date from waitinglist where waitinglist.book_identifier =
                                                                    OLD.book_identifier and waiting_position = 1);
      set start_res_date = (select waitinglist.user_id from waitinglist where waitinglist.book_identifier =
                                                                  OLD.book_identifier and waiting_position = 1);
      set end_res_date = (select waitinglist.ending_reservation_date from waitinglist where waitinglist.book_identifier =
                                                                OLD.book_identifier and waiting_position = 1);
      set quantity = (select waitinglist.quantity from waitinglist where waitinglist.book_identifier =
                                                            OLD.book_identifier and waiting_position = 1);
  
      insert into booksreservations (user_id, book_identifier, book_title, reservation_date, starting_reservation_date,
                                     ending_reservation_date, quantity)
        values (user_id, old.book_identifier, old.book_title, reservation_date, start_res_date,end_res_date, quantity );
  
      delete from waitinglist where waitinglist.book_identifier = old.book_identifier and
                                waiting_position = 1;
    end if;
  end;

