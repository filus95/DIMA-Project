create trigger update_waitinglist_position
  after DELETE
  on waitinglist
  for each row
  begin
    update library_1.waitinglist set waiting_position = waiting_position - 1
    where library_1.waitinglist.book_identifier = OLD.book_identifier;
  end;

