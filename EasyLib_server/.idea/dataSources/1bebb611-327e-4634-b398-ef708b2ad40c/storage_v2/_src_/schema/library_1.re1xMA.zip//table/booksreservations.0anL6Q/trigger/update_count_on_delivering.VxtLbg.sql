create trigger update_count_on_delivering
  after DELETE
  on booksreservations
  for each row
  begin
    update library_1.books set quantity = quantity + OLD.quantity
    where library_1.books.identifier = OLD.book_identifier;
  end;

